import { db, storage } from "../script/firebase.js";
import { doc, updateDoc } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-firestore.js";
import { ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-storage.js";

let currentUser = null;

// ===============================
// USER LOADED
// ===============================
document.addEventListener("userLoaded", ({ detail: user }) => {
  currentUser = user;

  const preview = document.getElementById("profilePhotoPreview");

  if (user.photoUrl) {
    preview.src = user.photoUrl;
    preview.style.display = "block";
  }

  applyBookingUrl(user);
});

// ===============================
// DOM READY
// ===============================
document.addEventListener("DOMContentLoaded", () => {

  // -------------------------------
  // Dark Mode
  // -------------------------------
  const toggle = document.getElementById("darkToggle");

  if (toggle) {
    if (localStorage.getItem("darkMode") === "true") {
      toggle.checked = true;
      document.documentElement.setAttribute("data-theme", "dark");
    }

    toggle.addEventListener("change", () => {
      if (toggle.checked) {
        document.documentElement.setAttribute("data-theme", "dark");
        localStorage.setItem("darkMode", "true");
      } else {
        document.documentElement.removeAttribute("data-theme");
        localStorage.removeItem("darkMode");
      }
    });
  }

  // -------------------------------
  // Upload Button
  // -------------------------------
  const uploadBtn = document.getElementById("uploadPhotoBtn");
  const photoInput = document.getElementById("profilePhotoInput");
  const preview = document.getElementById("profilePhotoPreview");

  if (uploadBtn && photoInput) {

    uploadBtn.addEventListener("click", () => {
      photoInput.click();
    });

    photoInput.addEventListener("change", async (e) => {

      if (!currentUser) return;

      const file = e.target.files[0];
      if (!file) return;

      try {

        const storageRef = ref(storage, `businessPhotos/${currentUser.uid}`);

        await uploadBytes(storageRef, file);

        const url = await getDownloadURL(storageRef);

        await updateDoc(doc(db, "users", currentUser.uid), {
          photoUrl: url
        });

        preview.src = url;
        preview.style.display = "block";

        alert("Profile photo updated.");

      } catch (err) {

        console.error(err);
        alert("Photo upload failed.");

      }

    });

  }

  // -------------------------------
  // Use Current Location
  // -------------------------------
  const locationBtn = document.getElementById("useLocationBtn");

  if (locationBtn) {

    locationBtn.addEventListener("click", () => {

      if (!currentUser) return;

      if (!navigator.geolocation) {
        alert("Geolocation is not supported.");
        return;
      }

      navigator.geolocation.getCurrentPosition(

        async (pos) => {

          try {

            await updateDoc(doc(db, "users", currentUser.uid), {
              location: {
                lat: pos.coords.latitude,
                lng: pos.coords.longitude
              }
            });

            alert("Location saved!");

          } catch (err) {

            console.error(err);
            alert("Could not save location.");

          }

        },

        (err) => {

          console.error(err);
          alert("Could not get your location.");

        }

      );

    });

  }

  // -------------------------------
  // Copy Booking Link
  // -------------------------------
  const copyBtn = document.getElementById("copyLink");

  if (copyBtn) {

    copyBtn.addEventListener("click", async function () {

      const url = document.getElementById("siteUrl").textContent;

      try {

        await navigator.clipboard.writeText(url);

      } catch {

        prompt("Copy this URL:", url);

      }

      this.classList.add("copied");

      this.innerHTML = `
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none"
        stroke="currentColor" stroke-width="2.5"
        stroke-linecap="round" stroke-linejoin="round">
          <polyline points="20 6 9 17 4 12"/>
        </svg>
        Copied!
      `;

      setTimeout(() => {

        this.classList.remove("copied");

        this.innerHTML = `
          <svg width="13" height="13" viewBox="0 0 24 24"
          fill="none" stroke="currentColor"
          stroke-width="2" stroke-linecap="round"
          stroke-linejoin="round">
            <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
          </svg>
          Copy
        `;

      }, 2000);

    });

  }

});

// ===============================
// BOOKING URL
// ===============================
function applyBookingUrl(user) {

  const bookingUrl = new URL("booking.html", window.location.href);

  bookingUrl.searchParams.set("uid", user.uid);

  const siteUrl = document.getElementById("siteUrl");
  const openLink = document.getElementById("openBookingLink");

  if (siteUrl) {
    siteUrl.textContent = bookingUrl.href;
  }

  if (openLink) {
    openLink.href = bookingUrl.href;
  }

}

// If user is already available
if (window.currentUser?.uid) {
  currentUser = window.currentUser;
  applyBookingUrl(currentUser);
}
/* ─────────── Domain registration (mocked availability) ─────────── */
(() => {
  const SEEDS = {
    vet: ["kisallatrendelo.vet","drkovacs.vet","allatorvosbudapest.vet","allatorvosnev.hu","allatorvosnev.com"],
    walker: ["kutyasetaltatas.hu","setaltatoluca.hu","dogwalker.hu","dogwalk.pro","kutyasetaltato.com"],
    groomer: ["kutyakozmetika.hu","doggrooming.hu","grooming.pro","kutyaszepseg.hu"],
    trainer: ["kutyakikepzes.hu","dogtrainer.pro","kutyasuli.hu","trainingdog.hu"],
    boarding: ["kutypanzio.hu","doghotel.pro","kutyhotel.hu"],
    photographer: ["petphoto.hu","kutyfotos.hu","petstudio.pro"],
    other: ["kutyaszolgaltatas.hu","petpro.hu","kutyabarat.hu"],
  };
  const TLDS = [".hu",".com",".pro",".vet",".dog",".pet"];
  const PRICE = { hu:3990, com:4990, pro:6990, vet:12990, dog:8990, pet:7990 };

  const slug = s => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9-]/g,"").slice(0,40);
  const hash = s => { let h=5381; for (let i=0;i<s.length;i++) h=((h<<5)+h+s.charCodeAt(i))|0; return Math.abs(h); };
  const suggest = (q, prof) => {
    const seeds = SEEDS[prof] || SEEDS.other;
    const base = slug(q);
    const custom = base ? TLDS.map(t => base + t) : [];
    return [...new Set([...custom, ...seeds])].slice(0, 10);
  };
  const check = d => {
    const h = hash(d);
    const available = h % 3 !== 0;
    const tld = d.slice(d.lastIndexOf(".")+1);
    const price = available ? (PRICE[tld] ?? 5990) + (h % 500) : null;
    return { domain: d, available, price };
  };
  const fmt = n => n.toLocaleString("hu-HU") + " Ft/yr";

  const $q = document.getElementById("domainQuery");
  const $p = document.getElementById("domainProfession");
  const $btn = document.getElementById("domainSearchBtn");
  const $out = document.getElementById("domainResults");
  if (!$q || !$btn || !$out) return;

  const render = () => {
    const list = suggest($q.value.trim(), $p.value);
    $out.innerHTML = "";
    if (!list.length) { $out.innerHTML = '<div style="font-size:12px;color:#9ca3af;">Type a name and click Search.</div>'; return; }
    for (const d of list) {
      const r = check(d);
      const row = document.createElement("div");
      row.style.cssText = "display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px 12px;border:1px solid #f1f5f9;border-radius:10px;background:#fff;";
      row.innerHTML = `
        <div style="display:flex;flex-direction:column;">
          <span style="font-family:'DM Mono',monospace;font-size:13px;color:#111;">${d}</span>
          <span style="font-size:11px;color:${r.available ? '#059669' : '#dc2626'};">
            ${r.available ? 'Available · ' + fmt(r.price) : 'Taken'}
          </span>
        </div>
        ${r.available
          ? `<button class="copy-btn" data-domain="${d}">Register</button>`
          : `<span style="font-size:11px;color:#9ca3af;">—</span>`}
      `;
      $out.appendChild(row);
    }
    $out.querySelectorAll("button[data-domain]").forEach(b => {
      b.addEventListener("click", () => {
        alert(`Payment system coming soon.\n\nWe'll reserve ${b.dataset.domain} for you as soon as billing is live.`);
      });
    });
  };

  $btn.addEventListener("click", render);
  $q.addEventListener("keydown", e => { if (e.key === "Enter") render(); });
  render();
})();
