import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "WT Console — Vet & Dog Walking Admin" },
      {
        name: "description",
        content:
          "WT Console: manage clients, bookings, service plans, invoices and your own booking website.",
      },
      { property: "og:title", content: "WT Console — Vet & Dog Walking Admin" },
      {
        property: "og:description",
        content:
          "Manage clients, bookings, service plans and build your booking website in one console.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  useEffect(() => {
    window.location.replace("/html/index.html");
  }, []);
  return null;
}
